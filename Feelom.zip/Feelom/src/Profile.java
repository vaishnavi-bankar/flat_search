

import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Vaishnavi
 */
public class Profile extends javax.swing.JFrame{
     Boolean flag=false;
     int j,res=0,k=0;
     String filename;
     protected String queryy=("select * from flat");
    
     int id,fid,fid1,fid2,fid3;
     Boolean filter,washing,ac,geyser,security,balcony,furnished,lift,inverter;
     ResultSet rs3,rs1;
    /**
     * Creates new form Profile
     */
    public Profile(int id11) {
        
      //  rbtnoff.setVisible(false);
        id=id11;
        initComponents();
        rbtnoff.setVisible(false);
        jLabel1.setOpaque(true);
        lblexplore.setOpaque(true);
        lbladdflat.setOpaque(true);
        lblana.setOpaque(true);
        lblprofile.setOpaque(true);
        lblaboutus1.setOpaque(true);
        jLabel7.setOpaque(true);
        lblsignout.setOpaque(true);
        
        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        lblexplore.setBackground(Color.WHITE);
        lbladdflat.setBackground(new java.awt.Color(204, 204, 255));
        lblana.setBackground(new java.awt.Color(204, 204, 255));
        lblprofile.setBackground(new java.awt.Color(204, 204, 255));
        lblaboutus1.setBackground(new java.awt.Color(204, 204, 255));
        jLabel7.setBackground(new java.awt.Color(204, 204, 255));
        lblsignout.setBackground(new java.awt.Color(204, 204, 255));
        
        jPanel4.removeAll();
        jPanel4.repaint();
        jPanel4.revalidate();
        jPanel4.add(plexplore);
        jPanel4.repaint();
        jPanel4.revalidate();
        
        
         
        try{
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
        
        Statement st=con.createStatement();
        Statement st2=con.createStatement();
        String query=("select distinct(location) from flat");
        ResultSet rs =st.executeQuery(query);
        rs =st.executeQuery(query);
        
        while(rs.next())
        {
        comboloc.addItem(rs.getString("location"));
        }
        
        query=("select * from flat");
        rs1 =st.executeQuery(queryy);
        
        int i1=0;
        while(rs1.next())
        {
         i1++;
        }
         res=i1;
         lblresult.setText(res + "  results");
          rs1 =st.executeQuery(queryy);
        int i=0;
            flag=false;
           //  JOptionPane.showMessageDialog(null,flag);
            while(rs1.next() && flag==false)
               {  
                  // JOptionPane.showMessageDialog(null,"2");
                  if(i%3==0) 
                  {lbl1area.setText((rs1.getString("location")));
                  lbl1price.setText(rs1.getString("rent"));
                  lbl1type.setText(rs1.getString("stay"));
                  lbl1bhk.setText(rs1.getString("type"));
                  fid1=rs1.getInt("f_id");
                   
                 query=("select photo from fphoto where f_id="+ fid1);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic1.getWidth(),lblpic1.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic1.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
               
                  if(i%3==1) 
                  {lbl2area.setText((rs1.getString("location")));
                   lbl2price.setText(rs1.getString("rent"));
                   lbl2type.setText(rs1.getString("stay"));
                   lbl2bhk.setText(rs1.getString("type"));
                   fid2=rs1.getInt("f_id");
                   
                   query=("select photo from fphoto where f_id="+ fid2);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic2.getWidth(),lblpic2.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic2.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
               
                  if(i%3==2) 
                  {lbl3area.setText((rs1.getString("location")));
                   lbl3price.setText(rs1.getString("rent"));
                   lbl3type.setText(rs1.getString("stay"));
                   lbl3bhk.setText(rs1.getString("type"));
                   flag=true;
                   fid3=rs1.getInt("f_id");
                   
                   
                   query=("select photo from fphoto where f_id="+ fid3);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic3.getWidth(),lblpic3.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic3.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
                 
                   
                   i++;
                }
         //  JOptionPane.showMessageDialog(null,"DATA FETCHED");     
         
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
    }
    
    
    
    
    public Profile(int id11,String str)
    {
              
      //  rbtnoff.setVisible(false);
        queryy=str;
        id=id11;
        initComponents();
        rbtnoff.setVisible(false);
        jLabel1.setOpaque(true);
        lblexplore.setOpaque(true);
        lbladdflat.setOpaque(true);
        lblana.setOpaque(true);
        lblprofile.setOpaque(true);
      lblaboutus1.setOpaque(true);
        jLabel7.setOpaque(true);
        lblsignout.setOpaque(true);
        
        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        lblexplore.setBackground(Color.WHITE);
        lbladdflat.setBackground(new java.awt.Color(204, 204, 255));
        lblana.setBackground(new java.awt.Color(204, 204, 255));
        lblprofile.setBackground(new java.awt.Color(204, 204, 255));
       lblaboutus1.setBackground(new java.awt.Color(204, 204, 255));
        jLabel7.setBackground(new java.awt.Color(204, 204, 255));
        lblsignout.setBackground(new java.awt.Color(204, 204, 255));
        
        jPanel4.removeAll();
        jPanel4.repaint();
        jPanel4.revalidate();
        jPanel4.add(plexplore);
        jPanel4.repaint();
        jPanel4.revalidate();
        
        
         
        try{
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
        
        Statement st=con.createStatement();
        Statement st2=con.createStatement();
        String query=("select distinct(location) from flat");
        ResultSet rs =st.executeQuery(query);
        rs =st.executeQuery(query);
        
        while(rs.next())
        {
        comboloc.addItem(rs.getString("location"));
        }
        
        query=("select * from flat");
        rs1 =st.executeQuery(queryy);
        
        int i1=0;
        while(rs1.next())
        {
         i1++;
        }
         res=i1;
         lblresult.setText(res + "  results");
          rs1 =st.executeQuery(queryy);
        int i=0;
            flag=false;
            // JOptionPane.showMessageDialog(null,flag);
            while(rs1.next() && flag==false)
               {  
                 //  JOptionPane.showMessageDialog(null,"2");
                  if(i%3==0) 
                  {lbl1area.setText((rs1.getString("location")));
                  lbl1price.setText(rs1.getString("rent"));
                  lbl1type.setText(rs1.getString("stay"));
                  lbl1bhk.setText(rs1.getString("type"));
                  fid1=rs1.getInt("f_id");
                  
                     query=("select photo from fphoto where f_id="+ fid1);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic1.getWidth(),lblpic1.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic1.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                   
                  }
               
                  if(i%3==1) 
                  {lbl2area.setText((rs1.getString("location")));
                   lbl2price.setText(rs1.getString("rent"));
                   lbl2type.setText(rs1.getString("stay"));
                   lbl2bhk.setText(rs1.getString("type"));
                   fid2=rs1.getInt("f_id");
                   
                    query=("select photo from fphoto where f_id="+ fid2);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic2.getWidth(),lblpic2.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic2.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                   
                  }
               
                  if(i%3==2) 
                  {lbl3area.setText((rs1.getString("location")));
                   lbl3price.setText(rs1.getString("rent"));
                   lbl3type.setText(rs1.getString("stay"));
                   lbl3bhk.setText(rs1.getString("type"));
                   flag=true;
                   fid3=rs1.getInt("f_id");
                   
                   query=("select photo from fphoto where f_id="+ fid3);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic3.getWidth(),lblpic3.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic3.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
                 
                   
                   i++;
                }
         //  JOptionPane.showMessageDialog(null,"DATA FETCHED");     
         
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel7 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jTextField5 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jTextField10 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jRadioButton1 = new javax.swing.JRadioButton();
        jLabel34 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jPanel32 = new javax.swing.JPanel();
        jPanel33 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        jCheckBox11 = new javax.swing.JCheckBox();
        jLabel58 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jInternalFrame1 = new javax.swing.JInternalFrame();
        jPasswordField1 = new javax.swing.JPasswordField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jFormattedTextField1 = new javax.swing.JFormattedTextField();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lblprofile = new javax.swing.JLabel();
        lblexplore = new javax.swing.JLabel();
        lbladdflat = new javax.swing.JLabel();
        lblana = new javax.swing.JLabel();
        lblsignout = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lblaboutus1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        plexplore = new javax.swing.JPanel();
        jPanel26 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        comboloc = new javax.swing.JComboBox();
        jButton5 = new javax.swing.JButton();
        jPanel29 = new javax.swing.JPanel();
        jPanel30 = new javax.swing.JPanel();
        lblpic2 = new javax.swing.JLabel();
        lbl2price = new javax.swing.JLabel();
        lbl2bhk = new javax.swing.JLabel();
        lbl2area = new javax.swing.JLabel();
        lbl2type = new javax.swing.JLabel();
        lbl2size = new javax.swing.JLabel();
        jPanel34 = new javax.swing.JPanel();
        lblpic1 = new javax.swing.JLabel();
        lbl1price = new javax.swing.JLabel();
        lbl1type = new javax.swing.JLabel();
        lbl1bhk = new javax.swing.JLabel();
        lbl1size = new javax.swing.JLabel();
        lbl1area = new javax.swing.JLabel();
        jPanel35 = new javax.swing.JPanel();
        lblpic3 = new javax.swing.JLabel();
        lbl3price = new javax.swing.JLabel();
        lbl3bhk = new javax.swing.JLabel();
        lbl3area = new javax.swing.JLabel();
        lbl3type = new javax.swing.JLabel();
        lbl3size = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        lblresult = new javax.swing.JLabel();
        pladd = new javax.swing.JPanel();
        flatimg = new javax.swing.JLabel();
        txtlocation = new javax.swing.JTextField();
        txtfloor = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        chksecurity = new javax.swing.JCheckBox();
        chkwash = new javax.swing.JCheckBox();
        chkgeyser = new javax.swing.JCheckBox();
        chkfilter = new javax.swing.JCheckBox();
        chkinverter = new javax.swing.JCheckBox();
        chkbalcony = new javax.swing.JCheckBox();
        chkac = new javax.swing.JCheckBox();
        chklift = new javax.swing.JCheckBox();
        chkfurnished = new javax.swing.JCheckBox();
        jLabel56 = new javax.swing.JLabel();
        txtrent = new javax.swing.JTextField();
        jLabel57 = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        jLabel61 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        upload = new javax.swing.JButton();
        rbtngirls = new javax.swing.JRadioButton();
        rbtnboys = new javax.swing.JRadioButton();
        rbtnany = new javax.swing.JRadioButton();
        rbtnoff = new javax.swing.JRadioButton();
        addflat1 = new javax.swing.JButton();
        jPanel14 = new javax.swing.JPanel();
        date = new javax.swing.JComboBox();
        year = new javax.swing.JComboBox();
        month = new javax.swing.JComboBox();
        jLabel62 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        cmbtype = new javax.swing.JComboBox();
        jLabel59 = new javax.swing.JLabel();
        jLabel64 = new javax.swing.JLabel();
        txtlocation1 = new javax.swing.JTextField();
        jLabel65 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtdescription = new javax.swing.JTextArea();
        lblcount = new javax.swing.JLabel();
        plabout = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        plprofile = new javax.swing.JPanel();
        jPanel27 = new javax.swing.JPanel();
        jPanel28 = new javax.swing.JPanel();
        lbldisplay = new javax.swing.JLabel();
        lbledit = new javax.swing.JLabel();
        jPanel22 = new javax.swing.JPanel();
        pnledit = new javax.swing.JPanel();
        lblphoto1 = new javax.swing.JLabel();
        txtcontact = new javax.swing.JTextField();
        txtfname = new javax.swing.JTextField();
        txtlname = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        pnldisplay1 = new javax.swing.JPanel();
        lblphoto3 = new javax.swing.JLabel();
        lblname2 = new javax.swing.JLabel();
        lblcontact2 = new javax.swing.JLabel();
        lblemail2 = new javax.swing.JLabel();
        plprofile1 = new javax.swing.JPanel();
        jPanel36 = new javax.swing.JPanel();
        lblphoto2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        pnlflat = new javax.swing.JPanel();
        lfloor = new javax.swing.JLabel();
        lrent = new javax.swing.JLabel();
        ldate = new javax.swing.JLabel();
        ltype = new javax.swing.JLabel();
        lstay = new javax.swing.JLabel();
        llocation = new javax.swing.JLabel();
        llocation2 = new javax.swing.JLabel();
        lfloor1 = new javax.swing.JLabel();
        ltype1 = new javax.swing.JLabel();
        lrent1 = new javax.swing.JLabel();
        ldate1 = new javax.swing.JLabel();
        laddress2 = new javax.swing.JLabel();
        laddress6 = new javax.swing.JLabel();
        ldescription1 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        laddress3 = new javax.swing.JLabel();
        laddress5 = new javax.swing.JLabel();
        lblname1 = new javax.swing.JLabel();
        laddress4 = new javax.swing.JLabel();
        lblcontact1 = new javax.swing.JLabel();
        lblemail1 = new javax.swing.JLabel();
        laddress1 = new javax.swing.JLabel();
        ltype2 = new javax.swing.JLabel();
        laddress = new javax.swing.JLabel();
        laddress7 = new javax.swing.JLabel();
        lblam = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        lblcount2 = new javax.swing.JLabel();
        planalysis = new javax.swing.JPanel();
        btnpiearea = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jLabel12.setText("jLabel12");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 299, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jTextField5.setText("jTextField5");

        jTextField9.setText("CONTACT NO");

        jTextField10.setText("jTextField10");

        jTextField8.setText("LAST NAME");

        jTextField11.setText("jTextField11");

        jLabel23.setText("jLabel23");

        jTextField6.setText("YOUR PROFILE");

        jRadioButton1.setText("jRadioButton1");

        jLabel34.setText("L");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        javax.swing.GroupLayout jPanel32Layout = new javax.swing.GroupLayout(jPanel32);
        jPanel32.setLayout(jPanel32Layout);
        jPanel32Layout.setHorizontalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 397, Short.MAX_VALUE)
        );
        jPanel32Layout.setVerticalGroup(
            jPanel32Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 406, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel33Layout = new javax.swing.GroupLayout(jPanel33);
        jPanel33.setLayout(jPanel33Layout);
        jPanel33Layout.setHorizontalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 343, Short.MAX_VALUE)
        );
        jPanel33Layout.setVerticalGroup(
            jPanel33Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 501, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel31Layout = new javax.swing.GroupLayout(jPanel31);
        jPanel31.setLayout(jPanel31Layout);
        jPanel31Layout.setHorizontalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 367, Short.MAX_VALUE)
        );
        jPanel31Layout.setVerticalGroup(
            jPanel31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 527, Short.MAX_VALUE)
        );

        jCheckBox11.setText("jCheckBox1");

        jLabel58.setText("jLabel58");

        jLabel1.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText(" HELP");
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jInternalFrame1.setVisible(true);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPasswordField1.setText("jPasswordField1");

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane3.setViewportView(jTextArea2);

        jFormattedTextField1.setText("jFormattedTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));

        jLabel9.setFont(new java.awt.Font("Segoe Print", 1, 48)); // NOI18N
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("FEELOM");

        jPanel5.setBackground(new java.awt.Color(204, 204, 255));
        jPanel5.setToolTipText("");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1210, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 39, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jLabel9)
                .addGap(115, 115, 115)
                .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(55, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(29, 29, 29))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(66, 66, 66))))
        );

        jPanel3.setBackground(new java.awt.Color(204, 204, 255));

        lblprofile.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        lblprofile.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblprofile.setText("PROFILE");
        lblprofile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblprofileMouseClicked(evt);
            }
        });

        lblexplore.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        lblexplore.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblexplore.setText("EXPLORE");
        lblexplore.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblexploreMouseClicked(evt);
            }
        });

        lbladdflat.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        lbladdflat.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbladdflat.setText("ADD FLAT");
        lbladdflat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbladdflatMouseClicked(evt);
            }
        });

        lblana.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        lblana.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblana.setText("ANALYSIS");
        lblana.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblanaMouseClicked(evt);
            }
        });

        lblsignout.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        lblsignout.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblsignout.setText(" SIGN OUT");
        lblsignout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblsignoutMouseClicked(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe Print", 0, 13)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblaboutus1.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        lblaboutus1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblaboutus1.setText("ABOUT US");
        lblaboutus1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblaboutus1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lbladdflat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lblexplore, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lblprofile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lblana, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(304, 304, 304)
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 13, Short.MAX_VALUE))
            .addComponent(lblsignout, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lblaboutus1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(lblprofile, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblexplore, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbladdflat, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblana, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblaboutus1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblsignout, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(255, 255, 204));
        jPanel4.setLayout(new java.awt.CardLayout());

        plexplore.setBackground(new java.awt.Color(204, 255, 204));

        jPanel26.setBackground(new java.awt.Color(204, 255, 204));

        jLabel22.setBackground(new java.awt.Color(204, 204, 255));
        jLabel22.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("FILTER");
        jLabel22.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel22.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel22MouseClicked(evt);
            }
        });

        jLabel24.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        jLabel24.setText("LOCATION");

        comboloc.setFont(new java.awt.Font("Segoe Print", 0, 16)); // NOI18N
        comboloc.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "ANY" }));
        comboloc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combolocActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Arial Black", 1, 18)); // NOI18N
        jButton5.setText("GO");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel26Layout = new javax.swing.GroupLayout(jPanel26);
        jPanel26.setLayout(jPanel26Layout);
        jPanel26Layout.setHorizontalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel26Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel24)
                .addGap(18, 18, 18)
                .addComponent(comboloc, javax.swing.GroupLayout.PREFERRED_SIZE, 740, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton5)
                .addGap(64, 64, 64)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel26Layout.setVerticalGroup(
            jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel26Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(jPanel26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboloc)
                    .addComponent(jLabel24)
                    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        jPanel29.setBackground(new java.awt.Color(153, 153, 255));

        lblpic2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblpic2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lbl2price.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N

        lbl2bhk.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N

        lbl2area.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N

        lbl2type.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N

        lbl2size.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N
        lbl2size.setForeground(new java.awt.Color(204, 0, 0));
        lbl2size.setText("more details");
        lbl2size.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl2sizeMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel30Layout = new javax.swing.GroupLayout(jPanel30);
        jPanel30.setLayout(jPanel30Layout);
        jPanel30Layout.setHorizontalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                        .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(lbl2bhk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbl2area, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                                .addComponent(lbl2type, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(25, 25, 25))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                                .addComponent(lbl2size, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblpic2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel30Layout.createSequentialGroup()
                                .addComponent(lbl2price, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
        );
        jPanel30Layout.setVerticalGroup(
            jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel30Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblpic2, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel30Layout.createSequentialGroup()
                        .addComponent(lbl2price, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbl2type, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl2bhk, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl2area, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel30Layout.createSequentialGroup()
                        .addComponent(lbl2size, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        lblpic1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblpic1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lbl1price.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N

        lbl1type.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N

        lbl1bhk.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N

        lbl1size.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N
        lbl1size.setForeground(new java.awt.Color(204, 0, 0));
        lbl1size.setText("more details");
        lbl1size.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl1sizeMouseClicked(evt);
            }
        });

        lbl1area.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N

        javax.swing.GroupLayout jPanel34Layout = new javax.swing.GroupLayout(jPanel34);
        jPanel34.setLayout(jPanel34Layout);
        jPanel34Layout.setHorizontalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel34Layout.createSequentialGroup()
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(lbl1bhk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbl1area, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel34Layout.createSequentialGroup()
                                .addComponent(lbl1type, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(25, 25, 25))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel34Layout.createSequentialGroup()
                                .addComponent(lbl1size, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblpic1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel34Layout.createSequentialGroup()
                                .addComponent(lbl1price, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
        );
        jPanel34Layout.setVerticalGroup(
            jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel34Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblpic1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel34Layout.createSequentialGroup()
                        .addComponent(lbl1price, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel34Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbl1type, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl1bhk, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl1area, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel34Layout.createSequentialGroup()
                        .addComponent(lbl1size, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        jPanel35.setForeground(new java.awt.Color(204, 0, 0));

        lblpic3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblpic3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        lbl3price.setFont(new java.awt.Font("Segoe Script", 1, 20)); // NOI18N

        lbl3bhk.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N

        lbl3area.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N

        lbl3type.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N

        lbl3size.setFont(new java.awt.Font("Segoe Print", 1, 16)); // NOI18N
        lbl3size.setForeground(new java.awt.Color(204, 0, 0));
        lbl3size.setText("more details");
        lbl3size.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbl3sizeMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel35Layout = new javax.swing.GroupLayout(jPanel35);
        jPanel35.setLayout(jPanel35Layout);
        jPanel35Layout.setHorizontalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(lbl3bhk, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lbl3area, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                                .addComponent(lbl3type, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(25, 25, 25))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                                .addComponent(lbl3size, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblpic3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel35Layout.createSequentialGroup()
                                .addComponent(lbl3price, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addContainerGap())))
        );
        jPanel35Layout.setVerticalGroup(
            jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel35Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblpic3, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel35Layout.createSequentialGroup()
                        .addComponent(lbl3price, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lbl3type, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lbl3bhk, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbl3area, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel35Layout.createSequentialGroup()
                        .addComponent(lbl3size, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        jLabel35.setBackground(new java.awt.Color(153, 204, 255));
        jLabel35.setFont(new java.awt.Font("Segoe Script", 1, 48)); // NOI18N
        jLabel35.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel35.setText("<");
        jLabel35.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel35MouseClicked(evt);
            }
        });

        jLabel36.setBackground(new java.awt.Color(153, 204, 255));
        jLabel36.setFont(new java.awt.Font("Segoe Script", 1, 48)); // NOI18N
        jLabel36.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel36.setText(">");
        jLabel36.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel36MouseClicked(evt);
            }
        });

        lblresult.setBackground(new java.awt.Color(204, 204, 255));
        lblresult.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        lblresult.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblresult.setText("results");

        javax.swing.GroupLayout jPanel29Layout = new javax.swing.GroupLayout(jPanel29);
        jPanel29.setLayout(jPanel29Layout);
        jPanel29Layout.setHorizontalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel29Layout.createSequentialGroup()
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(72, 72, 72)
                        .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(344, 344, 344)
                        .addComponent(lblresult, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel29Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 61, Short.MAX_VALUE)
                        .addComponent(jPanel30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(64, 64, 64)
                        .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(34, 34, 34))
        );
        jPanel29Layout.setVerticalGroup(
            jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel29Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel30, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel34, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel35, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblresult, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(81, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout plexploreLayout = new javax.swing.GroupLayout(plexplore);
        plexplore.setLayout(plexploreLayout);
        plexploreLayout.setHorizontalGroup(
            plexploreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(plexploreLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(plexploreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel29, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        plexploreLayout.setVerticalGroup(
            plexploreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(plexploreLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel29, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel4.add(plexplore, "card2");

        pladd.setBackground(new java.awt.Color(255, 204, 255));

        flatimg.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        flatimg.setText("NO PREVIEW AVAILABLE");
        flatimg.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtlocation.setFont(new java.awt.Font("Segoe Script", 0, 16)); // NOI18N
        txtlocation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtlocationActionPerformed(evt);
            }
        });

        txtfloor.setFont(new java.awt.Font("Segoe Script", 0, 16)); // NOI18N

        chksecurity.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        chksecurity.setText("SECURITY");

        chkwash.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        chkwash.setText("WASHING MACHINE");

        chkgeyser.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        chkgeyser.setText("GEYSER");
        chkgeyser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkgeyserActionPerformed(evt);
            }
        });

        chkfilter.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        chkfilter.setText("FILTER");

        chkinverter.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        chkinverter.setText("INVERTER");

        chkbalcony.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        chkbalcony.setText("BALCONY");
        chkbalcony.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkbalconyActionPerformed(evt);
            }
        });

        chkac.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        chkac.setText("AC");

        chklift.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        chklift.setText("LIFT");

        chkfurnished.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        chkfurnished.setText("FURNISHED");

        jLabel56.setFont(new java.awt.Font("Segoe Script", 1, 22)); // NOI18N
        jLabel56.setText("BASIC DETAILS");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(chkfilter)
                    .addComponent(chksecurity)
                    .addComponent(chkinverter))
                .addGap(88, 88, 88)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel56)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(chkac)
                            .addComponent(chkgeyser)
                            .addComponent(chkfurnished))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(chklift)
                            .addComponent(chkbalcony)
                            .addComponent(chkwash))
                        .addGap(24, 24, 24))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jLabel56, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chkwash)
                    .addComponent(chkgeyser)
                    .addComponent(chkfilter))
                .addGap(39, 39, 39)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chkac)
                    .addComponent(chksecurity)
                    .addComponent(chkbalcony))
                .addGap(45, 45, 45)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chklift)
                    .addComponent(chkfurnished)
                    .addComponent(chkinverter))
                .addGap(87, 87, 87))
        );

        txtrent.setFont(new java.awt.Font("Segoe Script", 0, 16)); // NOI18N
        txtrent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtrentActionPerformed(evt);
            }
        });

        jLabel57.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jLabel57.setText("FLOOR NO.");

        jLabel60.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jLabel60.setText("LOCATION");

        jLabel61.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jLabel61.setText("RENT ( PER MONTH )");

        jLabel63.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jLabel63.setText("DESCRIPTION ");

        upload.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        upload.setText("INSERT PHOTO");
        upload.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uploadActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbtngirls);
        rbtngirls.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        rbtngirls.setText("GIRLS");
        rbtngirls.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtngirlsActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbtnboys);
        rbtnboys.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        rbtnboys.setText("BOYS");
        rbtnboys.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnboysActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbtnany);
        rbtnany.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        rbtnany.setSelected(true);
        rbtnany.setText("ANY");

        buttonGroup1.add(rbtnoff);
        rbtnoff.setOpaque(false);
        rbtnoff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbtnoffActionPerformed(evt);
            }
        });

        addflat1.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        addflat1.setText("ADD FLAT");
        addflat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addflat1ActionPerformed(evt);
            }
        });

        date.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        date.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "DATE", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        year.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        year.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "YEAR", "2019", "2020", " " }));

        month.setFont(new java.awt.Font("Segoe Script", 1, 16)); // NOI18N
        month.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "MONTH", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" }));

        jLabel62.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jLabel62.setText("AVAILABLE AT");

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel14Layout.createSequentialGroup()
                        .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(month, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(year, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(48, Short.MAX_VALUE))
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel62, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(month, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(year, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        cmbtype.setFont(new java.awt.Font("Segoe Script", 0, 16)); // NOI18N
        cmbtype.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1 R", "1 RK", "1 BHK", "2 BHK", "3 BHK", " ", " " }));
        cmbtype.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbtypeActionPerformed(evt);
            }
        });

        jLabel59.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jLabel59.setText("TYPE");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbtype, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel59, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel59)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cmbtype, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jLabel64.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jLabel64.setText("ADDRESS");

        txtlocation1.setFont(new java.awt.Font("Segoe Script", 0, 16)); // NOI18N
        txtlocation1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtlocation1ActionPerformed(evt);
            }
        });

        jLabel65.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jLabel65.setText("STAYING PREFERENCE");

        txtdescription.setColumns(20);
        txtdescription.setRows(5);
        jScrollPane1.setViewportView(txtdescription);

        lblcount.setFont(new java.awt.Font("Segoe Print", 1, 24)); // NOI18N
        lblcount.setText("+0");

        javax.swing.GroupLayout pladdLayout = new javax.swing.GroupLayout(pladd);
        pladd.setLayout(pladdLayout);
        pladdLayout.setHorizontalGroup(
            pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pladdLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pladdLayout.createSequentialGroup()
                        .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(pladdLayout.createSequentialGroup()
                            .addComponent(upload, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(101, 101, 101)
                            .addComponent(lblcount, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(flatimg, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel63)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 437, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pladdLayout.createSequentialGroup()
                        .addComponent(jLabel60)
                        .addGap(18, 18, 18)
                        .addComponent(txtlocation))
                    .addGroup(pladdLayout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pladdLayout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addComponent(jLabel61)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtrent, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(jLabel57)
                                .addGap(18, 18, 18)
                                .addComponent(txtfloor))
                            .addGroup(pladdLayout.createSequentialGroup()
                                .addComponent(jLabel64)
                                .addGap(18, 18, 18)
                                .addComponent(txtlocation1))))
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pladdLayout.createSequentialGroup()
                        .addGap(0, 15, Short.MAX_VALUE)
                        .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pladdLayout.createSequentialGroup()
                                .addComponent(rbtngirls)
                                .addGap(18, 18, 18)
                                .addComponent(rbtnboys)
                                .addGap(18, 18, 18)
                                .addComponent(rbtnany)
                                .addGap(18, 18, 18)
                                .addComponent(rbtnoff))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pladdLayout.createSequentialGroup()
                                .addComponent(jLabel65)
                                .addGap(146, 146, 146)))
                        .addGap(168, 168, 168)
                        .addComponent(addflat1, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        pladdLayout.setVerticalGroup(
            pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pladdLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pladdLayout.createSequentialGroup()
                        .addComponent(flatimg, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(upload, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblcount, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 71, Short.MAX_VALUE)
                        .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addComponent(jLabel63, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12))
                    .addGroup(pladdLayout.createSequentialGroup()
                        .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtlocation, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel60))
                        .addGap(28, 28, 28)
                        .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtlocation1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel64, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtrent, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel57)
                                .addComponent(txtfloor, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel61))
                        .addGap(40, 40, 40)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pladdLayout.createSequentialGroup()
                                .addGap(31, 31, 31)
                                .addComponent(jLabel65, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(pladdLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(rbtngirls)
                                        .addComponent(rbtnboys)
                                        .addComponent(rbtnany))
                                    .addComponent(rbtnoff, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(56, 56, 56))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pladdLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(addflat1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))))
        );

        jPanel4.add(pladd, "card2");

        plabout.setBackground(new java.awt.Color(255, 255, 204));

        jPanel24.setBackground(new java.awt.Color(204, 204, 204));

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel14.setText("TALK TO US");

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel19.setText("Divya Agarwal     : 9879879876 ");

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel21.setText("Vaishnavi Bankar : 8787878787");

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel26.setText("Swarna Gosavi    : 9879879870    ");

        javax.swing.GroupLayout jPanel24Layout = new javax.swing.GroupLayout(jPanel24);
        jPanel24.setLayout(jPanel24Layout);
        jPanel24Layout.setHorizontalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel24Layout.createSequentialGroup()
                .addContainerGap(148, Short.MAX_VALUE)
                .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel24Layout.createSequentialGroup()
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(95, 95, 95))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel24Layout.createSequentialGroup()
                            .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(197, 197, 197)))
                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel24Layout.setVerticalGroup(
            jPanel24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel24Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61)
                .addComponent(jLabel21)
                .addGap(18, 18, 18)
                .addComponent(jLabel19)
                .addGap(18, 18, 18)
                .addComponent(jLabel26)
                .addContainerGap(113, Short.MAX_VALUE))
        );

        jPanel25.setBackground(new java.awt.Color(204, 204, 255));

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel15.setText("MAIL US");

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel18.setText("vaishnavipbankar@gmail.com");

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel20.setText("abcdivya@gmail.com");

        jLabel27.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel27.setText("swarna.19@gmail.com");

        javax.swing.GroupLayout jPanel25Layout = new javax.swing.GroupLayout(jPanel25);
        jPanel25.setLayout(jPanel25Layout);
        jPanel25Layout.setHorizontalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addContainerGap(184, Short.MAX_VALUE)
                .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(206, 206, 206))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                        .addGroup(jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(151, 151, 151))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel25Layout.createSequentialGroup()
                        .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(59, 59, 59))))
        );
        jPanel25Layout.setVerticalGroup(
            jPanel25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel25Layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(55, 55, 55)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel20)
                .addGap(21, 21, 21)
                .addComponent(jLabel27)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel16.setFont(new java.awt.Font("Segoe Print", 1, 60)); // NOI18N
        jLabel16.setText("GET IN TOUCH");

        jLabel17.setFont(new java.awt.Font("Palatino Linotype", 1, 24)); // NOI18N
        jLabel17.setText("Want to get in touch ?We would love to hear from you.Here is how you can reach us ...");

        javax.swing.GroupLayout plaboutLayout = new javax.swing.GroupLayout(plabout);
        plabout.setLayout(plaboutLayout);
        plaboutLayout.setHorizontalGroup(
            plaboutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(plaboutLayout.createSequentialGroup()
                .addContainerGap(35, Short.MAX_VALUE)
                .addGroup(plaboutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(plaboutLayout.createSequentialGroup()
                        .addComponent(jPanel24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(49, 49, 49))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, plaboutLayout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addGap(387, 387, 387))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, plaboutLayout.createSequentialGroup()
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 1073, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(23, 23, 23))))
        );
        plaboutLayout.setVerticalGroup(
            plaboutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, plaboutLayout.createSequentialGroup()
                .addGap(68, 68, 68)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(88, 88, 88)
                .addGroup(plaboutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(64, Short.MAX_VALUE))
        );

        jPanel4.add(plabout, "card2");

        plprofile.setBackground(new java.awt.Color(204, 204, 204));

        jPanel28.setBackground(new java.awt.Color(204, 204, 255));

        lbldisplay.setBackground(new java.awt.Color(225, 225, 225));
        lbldisplay.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lbldisplay.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbldisplay.setText("DISPLAY");
        lbldisplay.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbldisplayMouseClicked(evt);
            }
        });

        lbledit.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        lbledit.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lbledit.setText("EDIT");
        lbledit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbleditMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel28Layout = new javax.swing.GroupLayout(jPanel28);
        jPanel28.setLayout(jPanel28Layout);
        jPanel28Layout.setHorizontalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lbledit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(lbldisplay, javax.swing.GroupLayout.DEFAULT_SIZE, 288, Short.MAX_VALUE)
        );
        jPanel28Layout.setVerticalGroup(
            jPanel28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel28Layout.createSequentialGroup()
                .addGap(218, 218, 218)
                .addComponent(lbldisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71)
                .addComponent(lbledit, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel22.setLayout(new java.awt.CardLayout());

        lblphoto1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblphoto1.setText("NO PREVIEW AVAILABLE");
        lblphoto1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblphoto1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblphoto1MouseClicked(evt);
            }
        });

        txtcontact.setFont(new java.awt.Font("Segoe Print", 0, 13)); // NOI18N
        txtcontact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtcontactActionPerformed(evt);
            }
        });

        txtfname.setFont(new java.awt.Font("Segoe Print", 0, 13)); // NOI18N

        txtlname.setFont(new java.awt.Font("Segoe Print", 0, 13)); // NOI18N
        txtlname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtlnameActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setText("SAVE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        jButton2.setText("UPDATE PHOTO");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        jButton3.setText("INSERT PHOTO");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("FIRST NAME");

        jLabel10.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("LAST NAME");

        jLabel25.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setText("CONTACT NO.");

        javax.swing.GroupLayout pnleditLayout = new javax.swing.GroupLayout(pnledit);
        pnledit.setLayout(pnleditLayout);
        pnleditLayout.setHorizontalGroup(
            pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnleditLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addGroup(pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnleditLayout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addComponent(lblphoto1, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addGroup(pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 90, Short.MAX_VALUE))
                    .addGroup(pnleditLayout.createSequentialGroup()
                        .addGroup(pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnleditLayout.createSequentialGroup()
                                .addComponent(txtcontact, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6))
                            .addGroup(pnleditLayout.createSequentialGroup()
                                .addGroup(pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtfname, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtlname, javax.swing.GroupLayout.PREFERRED_SIZE, 414, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addGap(24, 24, 24))
        );
        pnleditLayout.setVerticalGroup(
            pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnleditLayout.createSequentialGroup()
                .addGroup(pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnleditLayout.createSequentialGroup()
                        .addGap(118, 118, 118)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnleditLayout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(lblphoto1, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 105, Short.MAX_VALUE)
                .addGroup(pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtfname, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtlname, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnleditLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnleditLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(pnleditLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtcontact, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(53, 53, 53))
        );

        jPanel22.add(pnledit, "card2");

        lblphoto3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblphoto3.setText("NO PREVIEW AVAILABLE");
        lblphoto3.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        lblphoto3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblphoto3MouseClicked(evt);
            }
        });

        lblname2.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        lblname2.setText("NAME");
        lblname2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        lblcontact2.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        lblcontact2.setText("CONTACT NO:");
        lblcontact2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        lblemail2.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        lblemail2.setText("EMAIL");
        lblemail2.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));

        javax.swing.GroupLayout pnldisplay1Layout = new javax.swing.GroupLayout(pnldisplay1);
        pnldisplay1.setLayout(pnldisplay1Layout);
        pnldisplay1Layout.setHorizontalGroup(
            pnldisplay1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnldisplay1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblphoto3, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(pnldisplay1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblcontact2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 442, Short.MAX_VALUE)
                    .addComponent(lblname2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblemail2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pnldisplay1Layout.setVerticalGroup(
            pnldisplay1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnldisplay1Layout.createSequentialGroup()
                .addGap(109, 109, 109)
                .addGroup(pnldisplay1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnldisplay1Layout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addComponent(lblname2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44)
                        .addComponent(lblcontact2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(53, 53, 53)
                        .addComponent(lblemail2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblphoto3, javax.swing.GroupLayout.PREFERRED_SIZE, 479, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(136, Short.MAX_VALUE))
        );

        jPanel22.add(pnldisplay1, "card2");

        javax.swing.GroupLayout jPanel27Layout = new javax.swing.GroupLayout(jPanel27);
        jPanel27.setLayout(jPanel27Layout);
        jPanel27Layout.setHorizontalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jPanel22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );
        jPanel27Layout.setVerticalGroup(
            jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel27Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel27Layout.createSequentialGroup()
                        .addComponent(jPanel28, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout plprofileLayout = new javax.swing.GroupLayout(plprofile);
        plprofile.setLayout(plprofileLayout);
        plprofileLayout.setHorizontalGroup(
            plprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(plprofileLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        plprofileLayout.setVerticalGroup(
            plprofileLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, plprofileLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jPanel4.add(plprofile, "card2");

        plprofile1.setBackground(new java.awt.Color(204, 255, 204));

        jPanel36.setBackground(new java.awt.Color(204, 204, 255));

        lblphoto2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblphoto2.setText("NO PREVIEW AVAILABLE");
        lblphoto2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("<<");
        jLabel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText(">>");
        jLabel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });

        pnlflat.setBackground(new java.awt.Color(255, 255, 204));

        lfloor.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        lfloor.setText("floor");

        lrent.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        lrent.setText("rent");

        ldate.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        ldate.setText("date");

        ltype.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        ltype.setText("type");

        lstay.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        lstay.setText("prefrence");

        llocation.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        llocation.setText("location");

        llocation2.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        llocation2.setText("LOCATION");

        lfloor1.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        lfloor1.setText("FLOOR");

        ltype1.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        ltype1.setText("STAY PREFRENCE");

        lrent1.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        lrent1.setText("RENT");

        ldate1.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        ldate1.setText("AVAILABLE FROM");

        laddress2.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        laddress2.setText("ADDRESS");

        laddress6.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        laddress6.setText("DESCRIPTION");

        ldescription1.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        ldescription1.setText("description");

        laddress3.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        laddress3.setText("NAME");

        laddress5.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        laddress5.setText("EMAIL");

        lblname1.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        lblname1.setText("name");

        laddress4.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        laddress4.setText("CONTACT NO.");

        lblcontact1.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        lblcontact1.setText("contact");

        lblemail1.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        lblemail1.setText("email");

        laddress1.setFont(new java.awt.Font("Gabriola", 1, 36)); // NOI18N
        laddress1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        laddress1.setText("OWNER INFORMATION ");

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(laddress3, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblname1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblemail1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblcontact1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(laddress5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(laddress4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 290, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(laddress1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(laddress1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(laddress3, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblname1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(laddress5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblemail1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(laddress4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblcontact1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        ltype2.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        ltype2.setText("TYPE");

        laddress.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        laddress.setText("address");

        laddress7.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        laddress7.setText("AMENITIES");

        lblam.setFont(new java.awt.Font("Segoe Print", 1, 20)); // NOI18N
        lblam.setText("amenities");

        javax.swing.GroupLayout pnlflatLayout = new javax.swing.GroupLayout(pnlflat);
        pnlflat.setLayout(pnlflatLayout);
        pnlflatLayout.setHorizontalGroup(
            pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlflatLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pnlflatLayout.createSequentialGroup()
                        .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(ldate1, javax.swing.GroupLayout.DEFAULT_SIZE, 235, Short.MAX_VALUE)
                            .addComponent(lrent1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lfloor1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(llocation2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ltype1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ltype2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(laddress2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(laddress6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(laddress7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ldescription1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(laddress, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(pnlflatLayout.createSequentialGroup()
                                .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(llocation, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lfloor, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lrent, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ldate, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ltype, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnlflatLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(lstay, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblam, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        pnlflatLayout.setVerticalGroup(
            pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnlflatLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(llocation2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(llocation, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lfloor1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lfloor, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lrent1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lrent, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ldate1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ldate, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ltype2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ltype, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ltype1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lstay, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(laddress2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(laddress, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(laddress6)
                    .addComponent(ldescription1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnlflatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblam, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(laddress7))
                .addGap(18, 18, 18)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(8, 8, 8))
        );

        jButton4.setFont(new java.awt.Font("Segoe Print", 1, 18)); // NOI18N
        jButton4.setText("BACK");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        lblcount2.setFont(new java.awt.Font("Segoe Print", 1, 24)); // NOI18N
        lblcount2.setText("+");

        javax.swing.GroupLayout jPanel36Layout = new javax.swing.GroupLayout(jPanel36);
        jPanel36.setLayout(jPanel36Layout);
        jPanel36Layout.setHorizontalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel36Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(192, 192, 192)
                        .addComponent(lblcount2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton4)
                    .addComponent(lblphoto2, javax.swing.GroupLayout.PREFERRED_SIZE, 550, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(pnlflat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel36Layout.setVerticalGroup(
            jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel36Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel36Layout.createSequentialGroup()
                        .addComponent(lblphoto2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel36Layout.createSequentialGroup()
                                .addGroup(jPanel36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblcount2, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(81, 81, 81))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel36Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addComponent(jButton4)
                                .addGap(21, 21, 21))))
                    .addGroup(jPanel36Layout.createSequentialGroup()
                        .addComponent(pnlflat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 46, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout plprofile1Layout = new javax.swing.GroupLayout(plprofile1);
        plprofile1.setLayout(plprofile1Layout);
        plprofile1Layout.setHorizontalGroup(
            plprofile1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel36, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        plprofile1Layout.setVerticalGroup(
            plprofile1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel4.add(plprofile1, "card2");

        planalysis.setBackground(new java.awt.Color(255, 255, 204));

        btnpiearea.setText("PIE CHART(rent)");
        btnpiearea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnpieareaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout planalysisLayout = new javax.swing.GroupLayout(planalysis);
        planalysis.setLayout(planalysisLayout);
        planalysisLayout.setHorizontalGroup(
            planalysisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(planalysisLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnpiearea, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(904, Short.MAX_VALUE))
        );
        planalysisLayout.setVerticalGroup(
            planalysisLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(planalysisLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(btnpiearea, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(689, Short.MAX_VALUE))
        );

        jPanel4.add(planalysis, "card2");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 1251, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        // TODO add your handling code here:
         
        
    }//GEN-LAST:event_jLabel1MouseClicked

    private void lbldisplayMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldisplayMouseClicked
        // TODO add your handling code here:
        
        lbldisplay.setOpaque(true);
        lbledit.setOpaque(true);
        lbledit.setBackground(new java.awt.Color(204, 204, 255));
        lbldisplay.setBackground(Color.WHITE);
        
       
        
         try{
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
        
        Statement st=con.createStatement();
        String query=("select * from owner where o_id="+id);
        ResultSet rs =st.executeQuery(query);
             if(rs.first())
               {
               lblname2.setText((rs.getString("fname").concat(" ")).concat(rs.getString("lname")));
               lblcontact2.setText(rs.getString("contact"));
               lblemail2.setText(rs.getString("email"));
               }
                
         
             
             query=("select * from photo1 where o_id=" +id);
            rs =st.executeQuery(query);
             if(rs.next())
             {
                 byte[] img=rs.getBytes("photo");
                 ImageIcon image=new ImageIcon(img);
                Image im=image.getImage();
                 Image myImg=im.getScaledInstance(lblphoto3.getWidth(),lblphoto3.getWidth(),Image.SCALE_SMOOTH);
                ImageIcon newImage =new ImageIcon(myImg);
                 lblphoto3.setIcon(newImage);
             }
             else
             {
                 JOptionPane.showMessageDialog(null,"NO PHOTO");
             }
             
             //  JOptionPane.showMessageDialog(null,"DATA FETCHED"); 
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
         
        jLabel22.setBackground(Color.WHITE);
        jPanel22.removeAll();
        jPanel22.repaint();
        jPanel22.revalidate();
        jPanel22.add(pnldisplay1);
        jPanel22.repaint();
        jPanel22.revalidate();
    }//GEN-LAST:event_lbldisplayMouseClicked

    private void lbleditMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbleditMouseClicked

        
// TODO add your handling code here:
        lbldisplay.setOpaque(true);
        lbledit.setOpaque(true);
        lbldisplay.setBackground(new java.awt.Color(204, 204, 255));
        lbledit.setBackground(Color.WHITE);
        
        
        try{
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
        
        Statement st=con.createStatement();
        String query=("select * from owner where o_id="+id);
        ResultSet rs =st.executeQuery(query);
             if(rs.first())
               {
               txtfname.setText(rs.getString("fname"));
               txtlname.setText(rs.getString("lname"));
               txtcontact.setText(rs.getString("contact"));
              
               }
          // JOptionPane.showMessageDialog(null,"DATA FETCHED");     
             
            query=("select * from photo1 where o_id=" +id);
            rs =st.executeQuery(query);
            if(rs.next())
             {
                 byte[] img=rs.getBytes("photo");
                 ImageIcon image=new ImageIcon(img);
                 Image im=image.getImage();
                 Image myImg=im.getScaledInstance(lblphoto1.getWidth(),lblphoto1.getWidth(),Image.SCALE_SMOOTH);
                 ImageIcon newImage =new ImageIcon(myImg);
                 lblphoto1.setIcon(newImage);
             }
             else
             {
                 JOptionPane.showMessageDialog(null,"INSERT PROFILE PHOTO");
             }
         
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
        
        
        jLabel22.setBackground(Color.WHITE);
        jPanel22.removeAll();
        jPanel22.repaint();
        jPanel22.revalidate();
        jPanel22.add(pnledit);
        jPanel22.repaint();
        jPanel22.revalidate();
    }//GEN-LAST:event_lbleditMouseClicked

    private void chkgeyserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkgeyserActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkgeyserActionPerformed

    private void txtlocationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtlocationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtlocationActionPerformed

    private void cmbtypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbtypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbtypeActionPerformed

    private void txtrentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtrentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtrentActionPerformed

    private void uploadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uploadActionPerformed
        // TODO add your handling code here:
        int i,fidd=0;
        JFileChooser chooser =new JFileChooser();
        chooser.showOpenDialog(null);
        File f=chooser.getSelectedFile();
        filename =f.getAbsolutePath();
        JOptionPane.showMessageDialog(null,filename);
        ImageIcon imageicon =new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(flatimg.getWidth(),flatimg.getHeight(),Image.SCALE_SMOOTH));
        flatimg.setIcon(imageicon);
       
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");

            Statement st=con.createStatement();
            File file =new File(filename);
            FileInputStream fis=new FileInputStream(file);
            
            String query=("select max(f_id) as max from flat");
            ResultSet rs =st.executeQuery(query);
             while(rs.next())
               {
               fidd=rs.getInt("max")+1;
                }
            
            PreparedStatement ps=con.prepareStatement("insert into fphoto(f_id,photo) values(?,?)");
            ps.setInt(1,fidd);
            ps.setBinaryStream(2, fis,(int)file.length());
            ps.executeUpdate();
            ps.close();
            fis.close();
         
            JOptionPane.showMessageDialog(null,"IMAGE INSERTED" );
        
    
             query=("select count(f_id) as count1 from fphoto where f_id="+fidd);
             rs =st.executeQuery(query);
             while(rs.next())
               {
               lblcount.setText("+"+ rs.getInt("count1"));
                }
             con.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Exception "  +e);
        }
    }//GEN-LAST:event_uploadActionPerformed

    private void chkbalconyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkbalconyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_chkbalconyActionPerformed

    private void rbtngirlsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtngirlsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtngirlsActionPerformed

    private void rbtnboysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnboysActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnboysActionPerformed

    private void rbtnoffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbtnoffActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbtnoffActionPerformed

    private void addflat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addflat1ActionPerformed
        // TODO add your handling code here:
          
         while(true)
        {
            if(txtlocation.getText().equals(" "))
            {
                JOptionPane.showMessageDialog(null,"PLEASE FILL THE REQD. DETAILS.");
                txtlocation.requestFocus();
            }
            
            else
            if(txtrent.getText().equals(" "))
            {
                JOptionPane.showMessageDialog(null,"PLEASE FILL THE REQD. DETAILS.");
                txtrent.requestFocus();
            }
            else
            if(txtfloor.getText().equals(" "))
            {
                JOptionPane.showMessageDialog(null,"PLEASE FILL THE REQD. DETAILS.");
                txtfloor.requestFocus();
            }
           
            else    
            break;
        }    
         try
        {
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
            Statement st=con.createStatement();
            
            if(chkfilter.isSelected())
              filter=true;
            else 
               filter=false;
            
            if(chkwash.isSelected())
                washing=true;
            else
                washing=false;
            
            if(chkgeyser.isSelected())
                geyser=true;
                else
                geyser=false;
            
            if(chksecurity.isSelected())
                security=true;
                else
                security=false;
            
            if(chkac.isSelected())
                ac=true;
                else
                ac=false;
            if(chkbalcony.isSelected())
                balcony=true;
                else
                balcony=false;
            if(chkinverter.isSelected())
                inverter=true;
                else
                inverter=false;
            if(chklift.isSelected())
                lift=true;
                else
                lift=false;
            if(chkfurnished.isSelected())
                furnished=true;
                else
                furnished=false;
            
            String strtype=(String)cmbtype.getSelectedItem();
            String str1=(String)date.getSelectedItem();
            String str2=(String)month.getSelectedItem();
            String str3=(String)year.getSelectedItem();
            String str="-";
            
            String str4=str3.concat(str);
            String str5=str4.concat(str2);
            String str6=str5.concat(str);
            String strdate=str6.concat(str1);
            
            String strstay=null;
            if(rbtngirls.isSelected())
               strstay="girls";
            else if(rbtnboys.isSelected())
               strstay="boys";
            else if(rbtnany.isSelected())
               strstay="girls/boys";
                  
            
            String query=("insert into flat(location,rent,floor,type,date,stay,o_id,address,description)values('" + txtlocation.getText() +"',"  +  txtrent.getText()   +","   + txtfloor.getText() + ",'" + strtype +"','" + strdate + "','" + strstay+ "'," + id + ",'" + txtlocation1.getText()+ "','" + txtdescription.getText()+"')");
            st.executeUpdate(query);
            query=("insert into extra(filter,geyser,security,ac,balcony,inverter,furnished,lift,wm)values(" + filter + ","  + geyser + ","  + security+ ","  + ac+ ","  + balcony+ ","  + inverter+ ","  + furnished+ ","  +lift+ ","  + washing +")");
            st.executeUpdate(query);
          JOptionPane.showMessageDialog(null,"DATA INSERTED SUCCESSFULLY");
            /*
               query=("select * from owner where o_id="+id);
               ResultSet rs =st.executeQuery(query);
               if(rs.first())
               {
               txtfname.setText(rs.getString("fname"));
               txtlname.setText(rs.getString("lname"));
               txtcontact.setText(rs.getString("contact"));
              
               }*/
            
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
         
         
        
      
    }//GEN-LAST:event_addflat1ActionPerformed

    private void txtlocation1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtlocation1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtlocation1ActionPerformed

    private void jLabel22MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel22MouseClicked
        // TODO add your handling code here:
        
        filter filter=new filter(fid,id,this);
        filter.setVisible(true);
        
        
    }//GEN-LAST:event_jLabel22MouseClicked

    private void jLabel36MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel36MouseClicked
        // TODO add your handling code here:
          flag=false;
            try{
               Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
        
              Statement st=con.createStatement();
              Statement st2=con.createStatement();
              ResultSet rs1 =st.executeQuery(queryy);
               j++;
               int i=j*3;
               rs1.absolute(i);
               while(rs1.next() && flag==false)
               {  
                  if(i%3==0) 
                  {lbl1area.setText((rs1.getString("location")));
                   lbl1price.setText(rs1.getString("rent"));
                   lbl1type.setText(rs1.getString("stay"));
                   lbl1bhk.setText(rs1.getString("type"));
                   fid1=rs1.getInt("f_id");
                   
                   String query=("select photo from fphoto where f_id="+ fid1);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic1.getWidth(),lblpic1.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic1.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
               
                  if(i%3==1) 
                  {lbl2area.setText((rs1.getString("location")));
                   lbl2price.setText(rs1.getString("rent"));
                   lbl2type.setText(rs1.getString("stay"));
                   lbl2bhk.setText(rs1.getString("type"));
                    fid2=rs1.getInt("f_id");
                    
                    String query=("select photo from fphoto where f_id="+ fid2);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic2.getWidth(),lblpic2.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic2.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
               
                  if(i%3==2) 
                  {lbl3area.setText((rs1.getString("location")));
                   lbl3price.setText(rs1.getString("rent"));
                   lbl3type.setText(rs1.getString("stay"));
                   lbl3bhk.setText(rs1.getString("type"));
                   flag=true;
                    fid3=rs1.getInt("f_id");
                    
                    String query=("select photo from fphoto where f_id="+ fid3);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic3.getWidth(),lblpic3.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic3.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
                 
                   
                   i++;
                }
            
         //  JOptionPane.showMessageDialog(null,"DATA FETCHED");     
         
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
        
        
     
    }//GEN-LAST:event_jLabel36MouseClicked

    private void jLabel35MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel35MouseClicked
        // TODO add your handling code here:
        
         j=0;  fid=fid1;
      
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
        
        Statement st=con.createStatement();
     Statement st2=con.createStatement();
        ResultSet rs1 =st.executeQuery(queryy);
       
             int i=0;
            while(rs1.next() && flag==false)
               {  
                  
                  
                  if(i%3==0) 
                  {lbl1area.setText((rs1.getString("location")));
                  lbl1price.setText(rs1.getString("rent"));
                  lbl1type.setText(rs1.getString("stay"));
                  lbl1bhk.setText(rs1.getString("type"));
                  fid1=rs1.getInt("f_id");
                  
                  
                   
                    String query=("select photo from fphoto where f_id="+ fid1);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic1.getWidth(),lblpic1.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic1.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
               
                  if(i%3==1) 
                  {lbl2area.setText((rs1.getString("location")));
                   lbl2price.setText(rs1.getString("rent"));
                   lbl2type.setText(rs1.getString("stay"));
                   lbl2bhk.setText(rs1.getString("type"));
                   fid2=rs1.getInt("f_id");
                   
                   
                    
                    String query=("select photo from fphoto where f_id="+ fid2);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic2.getWidth(),lblpic2.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic2.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
               
                  if(i%3==2) 
                  {lbl3area.setText((rs1.getString("location")));
                   lbl3price.setText(rs1.getString("rent"));
                   lbl3type.setText(rs1.getString("stay"));
                   lbl3bhk.setText(rs1.getString("type"));
                   flag=true;
                   fid3=rs1.getInt("f_id");
                   
                    
                    String query=("select photo from fphoto where f_id="+ fid3);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic3.getWidth(),lblpic3.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic3.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
                 
                   
                   i++;
                }
         //  JOptionPane.showMessageDialog(null,"DATA FETCHED");     
         
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
    }//GEN-LAST:event_jLabel35MouseClicked

    private void lbl1sizeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl1sizeMouseClicked
        // TODO add your handling code here:
        int i;  fid=fid1;
      
        try{
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
        
        Statement st=con.createStatement();
        String query=("select * from flat inner join owner using(o_id) where f_id="+ fid);
        
        String imageq=("select photo from fphoto where f_id="+fid);
        ResultSet rs2=st.executeQuery(imageq);
     
        ResultSet rs =st.executeQuery(query);
             if(rs.first())
               {
               
               llocation.setText(rs.getString("location"));
               lrent.setText(rs.getString("rent"));
               lfloor.setText(rs.getString("floor"));
               ldate.setText(rs.getString("date"));
               lstay.setText(rs.getString("stay"));
               ltype.setText(rs.getString("type"));
               laddress.setText(rs.getString("address"));
               lblname1.setText(rs.getString("description"));
               lblname1.setText((rs.getString("fname").concat(" ")).concat(rs.getString("lname")));
               lblcontact1.setText(rs.getString("contact"));
               lblemail1.setText(rs.getString("email"));
               
               
             query=("select count(f_id) as count1 from fphoto where f_id="+fid);
             rs =st.executeQuery(query);
             while(rs.next())
               {
               lblcount2.setText("+"+ rs.getInt("count1"));
                }
             
             
            query=("select photo from fphoto where f_id="+ fid);
            rs3 =st.executeQuery(query);
            if(rs3.next())
             {
                 byte[] img=rs3.getBytes("photo");
                 ImageIcon image=new ImageIcon(img);
                 Image im=image.getImage();
                 Image myImg=im.getScaledInstance(lblphoto2.getWidth(),lblphoto2.getWidth(),Image.SCALE_SMOOTH);
                 ImageIcon newImage =new ImageIcon(myImg);
                 lblphoto2.setIcon(newImage);
             }
             else
             {
                 JOptionPane.showMessageDialog(null,"NO PHOTO");
             }
               
               }
         //  JOptionPane.showMessageDialog(null,"DATA FETCHED");     
            query=("select photo from fphoto where f_id="+ fid);
            rs =st.executeQuery(query);
            if(rs.next())
             {
                 byte[] img=rs.getBytes("photo");
                 ImageIcon image=new ImageIcon(img);
                 Image im=image.getImage();
                 Image myImg=im.getScaledInstance(lblphoto2.getWidth(),lblphoto2.getWidth(),Image.SCALE_SMOOTH);
                ImageIcon newImage =new ImageIcon(myImg);
                 lblphoto2.setIcon(newImage);
             }
             else
             {
                 JOptionPane.showMessageDialog(null,"NO PHOTO");
             }
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
        
        
        
        jPanel4.removeAll();
        jPanel4.repaint();
        jPanel4.revalidate();
        jPanel4.add(plprofile1);
        jPanel4.repaint();
        jPanel4.revalidate();
        
      
    }//GEN-LAST:event_lbl1sizeMouseClicked

    private void lbl2sizeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl2sizeMouseClicked
        // TODO add your handling code here:
        
        int i;  fid=fid2;
      
        try{
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
        
        Statement st=con.createStatement();
        String query=("select * from flat inner join owner using(o_id) where f_id="+ fid);
       // JOptionPane.showMessageDialog(null, fid);
        ResultSet rs =st.executeQuery(query);
             if(rs.first())
               {
               
               llocation.setText(rs.getString("location"));
               lrent.setText(rs.getString("rent"));
               lfloor.setText(rs.getString("floor"));
               ldate.setText(rs.getString("date"));
               lstay.setText(rs.getString("stay"));
               ltype.setText(rs.getString("type"));
               laddress.setText(rs.getString("address"));
               lblname1.setText(rs.getString("description"));
               lblname1.setText((rs.getString("fname").concat(" ")).concat(rs.getString("lname")));
               lblcontact1.setText(rs.getString("contact"));
               lblemail1.setText(rs.getString("email"));
               
            query=("select photo from fphoto where f_id="+ fid);
            ResultSet rs4 =st.executeQuery(query);
            if(rs4.next())
             {
                 byte[] img=rs4.getBytes("photo");
                 ImageIcon image=new ImageIcon(img);
                 Image im=image.getImage();
                 Image myImg=im.getScaledInstance(lblphoto2.getWidth(),lblphoto2.getWidth(),Image.SCALE_SMOOTH);
                 ImageIcon newImage =new ImageIcon(myImg);
                 lblphoto2.setIcon(newImage);
             }
             else
             {
                 JOptionPane.showMessageDialog(null,"NO PHOTO");
             }
               }
         //  JOptionPane.showMessageDialog(null,"DATA FETCHED");     
            query=("select photo from fphoto where f_id="+ fid);
            rs =st.executeQuery(query);
            if(rs.next())
             {
                 byte[] img=rs.getBytes("photo");
                 ImageIcon image=new ImageIcon(img);
                 Image im=image.getImage();
                 Image myImg=im.getScaledInstance(lblphoto2.getWidth(),lblphoto2.getWidth(),Image.SCALE_SMOOTH);
                 ImageIcon newImage =new ImageIcon(myImg);
                 lblphoto2.setIcon(newImage);
             }
             else
             {
                 JOptionPane.showMessageDialog(null,"NO PHOTO");
             }
            
              query=("select count(f_id) as count1 from fphoto where f_id="+fid);
             rs =st.executeQuery(query);
             while(rs.next())
               {
               lblcount2.setText("+"+ rs.getInt("count1"));
                }
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
        
        fid=fid2;
        jPanel4.removeAll();
        jPanel4.repaint();
        jPanel4.revalidate();
        jPanel4.add(plprofile1);
        jPanel4.repaint();
        jPanel4.revalidate();
        
    }//GEN-LAST:event_lbl2sizeMouseClicked

    private void lbl3sizeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbl3sizeMouseClicked
        // TODO add your handling code here:
        
        int i;  fid=fid3;
      
        try{
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
        
        Statement st=con.createStatement();
        String query=("select * from flat inner join owner using(o_id) where f_id="+ fid);
       // JOptionPane.showMessageDialog(null, fid);
        ResultSet rs =st.executeQuery(query);
             if(rs.first())
               {
               
               llocation.setText(rs.getString("location"));
               lrent.setText(rs.getString("rent"));
               lfloor.setText(rs.getString("floor"));
               ltype.setText(rs.getString("type"));
               ldate.setText(rs.getString("date"));
               lstay.setText(rs.getString("stay"));
               laddress.setText(rs.getString("address"));
               lblname1.setText(rs.getString("description"));
               lblname1.setText((rs.getString("fname").concat(" ")).concat(rs.getString("lname")));
               lblcontact1.setText(rs.getString("contact"));
               lblemail1.setText(rs.getString("email"));
               
         
             query=("select count(f_id) as count1 from fphoto where f_id="+fid);
             rs =st.executeQuery(query);
             while(rs.next())
               {
               lblcount2.setText("+"+ rs.getInt("count1"));
                }
             
               }
         //  JOptionPane.showMessageDialog(null,"DATA FETCHED");     
            query=("select photo from fphoto where f_id="+ fid);
            ResultSet rs5 =st.executeQuery(query);
            if(rs5.next())
             {
                 byte[] img=rs5.getBytes("photo");
                 ImageIcon image=new ImageIcon(img);
                 Image im=image.getImage();
                 Image myImg=im.getScaledInstance(lblphoto2.getWidth(),lblphoto2.getWidth(),Image.SCALE_SMOOTH);
                 ImageIcon newImage =new ImageIcon(myImg);
                 lblphoto2.setIcon(newImage);
             }
             else
             {
                 JOptionPane.showMessageDialog(null,"NO PHOTO");
             }
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
        
        
        jPanel4.removeAll();
        jPanel4.repaint();
        jPanel4.revalidate();
        jPanel4.add(plprofile1);
        jPanel4.repaint();
        jPanel4.revalidate();
    }//GEN-LAST:event_lbl3sizeMouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
          j=0;
        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        lblexplore.setBackground(Color.WHITE);
        lbladdflat.setBackground(new java.awt.Color(204, 204, 255));
        lblana.setBackground(new java.awt.Color(204, 204, 255));
        lblprofile.setBackground(new java.awt.Color(204, 204, 255));
        jLabel7.setBackground(new java.awt.Color(204, 204, 255));
        lblsignout.setBackground(new java.awt.Color(204, 204, 255));
        
        jPanel4.removeAll();
        jPanel4.repaint();
        jPanel4.revalidate();
        jPanel4.add(plexplore);
        jPanel4.repaint();
        jPanel4.revalidate();
        
    
        jLabel22.setBackground(Color.WHITE);
        jPanel22.removeAll();
        jPanel22.repaint();
        jPanel22.revalidate();
        jPanel22.add(pnldisplay1);
        jPanel22.repaint();
        jPanel22.revalidate();
        
        
        try{
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
        
        Statement st2=con.createStatement();
        int i=0;
      
            while(rs1.next() && flag==false)
               {  
                  
                  
                  if(i%3==0) 
                  {lbl1area.setText((rs1.getString("location")));
                  lbl1price.setText(rs1.getString("rent"));
                  lbl1type.setText(rs1.getString("stay"));
                  lbl1bhk.setText(rs1.getString("type"));
                  fid1=rs1.getInt("f_id");
                  
                 String query=("select photo from fphoto where f_id="+ fid1);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic1.getWidth(),lblpic1.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic1.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
             
                  }
               
                  if(i%3==1) 
                  {lbl2area.setText((rs1.getString("location")));
                   lbl2price.setText(rs1.getString("rent"));
                   lbl2type.setText(rs1.getString("stay"));
                   lbl2bhk.setText(rs1.getString("type"));
                   fid2=rs1.getInt("f_id");
             
                 String query=("select photo from fphoto where f_id="+ fid1);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic2.getWidth(),lblpic2.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic2.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
               
                  if(i%3==2) 
                  {lbl3area.setText((rs1.getString("location")));
                   lbl3price.setText(rs1.getString("rent"));
                   lbl3type.setText(rs1.getString("stay"));
                   lbl3bhk.setText(rs1.getString("type"));
                   flag=true;
                   fid3=rs1.getInt("f_id");
         
                String query=("select photo from fphoto where f_id="+ fid1);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic3.getWidth(),lblpic3.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic3.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
                   i++;
                }
         //  JOptionPane.showMessageDialog(null,"DATA FETCHED");     
         
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
        
        
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void combolocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combolocActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_combolocActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
      
         if(!comboloc.getSelectedItem().equals("ANY"))
        {
            queryy=("select * from flat where location='" +comboloc.getSelectedItem()+"'");
            
        }
        else
        {
            queryy=("select * from flat");
        }
         
         
        flag=false;
        try{
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
        
        Statement st=con.createStatement();
        Statement st2=con.createStatement();
        ResultSet rs1 =st.executeQuery(queryy);
     
        
        int i1=0;
        while(rs1.next())
        {
         i1++;
        }
         res=i1;
         lblresult.setText(res + "  results");
         
         rs1 =st.executeQuery(queryy);
        
         int i=0;
        
            while(rs1.next() && flag==false)
               {  
                       
                  if(i%3==0) 
                  {
                  
                  lbl1area.setText((rs1.getString("location")));
                  lbl1price.setText(rs1.getString("rent"));
                  lbl1type.setText(rs1.getString("stay"));
                  lbl1bhk.setText(rs1.getString("type"));
                  fid1=rs1.getInt("f_id");
               
                     String query=("select photo from fphoto where f_id="+ fid1);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic1.getWidth(),lblpic1.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic1.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
               
                  if(i%3==1) 
                  {lbl2area.setText((rs1.getString("location")));
                   lbl2price.setText(rs1.getString("rent"));
                   lbl2type.setText(rs1.getString("stay"));
                   lbl2bhk.setText(rs1.getString("type"));
                   fid2=rs1.getInt("f_id");
                   
                    String query=("select photo from fphoto where f_id="+ fid2);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic2.getWidth(),lblpic2.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic2.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  }
               
                  if(i%3==2) 
                  {lbl3area.setText((rs1.getString("location")));
                   lbl3price.setText(rs1.getString("rent"));
                   lbl3type.setText(rs1.getString("stay"));
                   lbl3bhk.setText(rs1.getString("type"));
                   flag=true;
                   fid3=rs1.getInt("f_id");
                
                    String query=("select photo from fphoto where f_id="+ fid3);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic3.getWidth(),lblpic3.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic3.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                  } i++;
                }
         //  JOptionPane.showMessageDialog(null,"DATA FETCHED");     
         
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }
        
    }//GEN-LAST:event_jButton5ActionPerformed

    private void btnpieareaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnpieareaActionPerformed

        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
            Statement st=con.createStatement();
            int range1=0,range2=0,range3=0;
            int x=0;
            String query=("select rent from flat");
            
            ResultSet rs=st.executeQuery(query);
            while(rs.next())
            {
               x=rs.getInt("rent");
                if(x<10000)
                {
                    range1++;
                    
                }
                else if(x<20000)
                {
                    range2++;
                    
                }
                else
                {
                    range3++;
                    
                }
                    
            }
            
            JOptionPane.showMessageDialog(null,range1+range2+range3); 
            
            DefaultPieDataset pieDataset = new DefaultPieDataset();
            pieDataset.setValue("below 10000", new Integer(range1));
            pieDataset.setValue("btn 10000-20000", new Integer(range2));
            pieDataset.setValue("above 20000", new Integer(range3));
            
            JFreeChart chart= ChartFactory.createPieChart("RENT",pieDataset,true,true,true);
            PiePlot p=(PiePlot) chart.getPlot();
            
            ChartFrame frame=new ChartFrame("RENT DATA",chart);
            
            frame.setVisible(true);
            frame.setLocationRelativeTo(null);
            frame.setSize(500, 600);
        }
        catch(SQLException e)
                {
                     JOptionPane.showMessageDialog(null,"exception"+ e);
                }
            
            
            
        
// TODO add your handling code here:
    }//GEN-LAST:event_btnpieareaActionPerformed

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        k++;
       int  i=k;
        try {
             // TODO add your handling code here:
             Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");

            Statement st=con.createStatement();
           String query=("select photo from fphoto where f_id="+fid);
           ResultSet rs =st.executeQuery(query);
           rs.absolute(i);
            if(rs.next())
            {
                 byte[] img=rs.getBytes("photo");
                 ImageIcon image=new ImageIcon(img);
                 Image im=image.getImage();
                 Image myImg=im.getScaledInstance(lblphoto2.getWidth(),lblphoto2.getWidth(),Image.SCALE_SMOOTH);
                 ImageIcon newImage =new ImageIcon(myImg);
                 lblphoto2.setIcon(newImage);
            
            }
            else
            {
                JOptionPane.showMessageDialog(null,"NO MORE IMAGES");
            }
         } catch (SQLException ex) {
             Logger.getLogger(Profile.class.getName()).log(Level.SEVERE, null, ex);
             JOptionPane.showMessageDialog(null,"exception"+ ex);

         }
        
    }//GEN-LAST:event_jLabel4MouseClicked

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        // TODO add your handling code here:
        try {
          k--;
          int i=k+1;
             Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");

            Statement st=con.createStatement();
           String query=("select photo from fphoto where f_id="+fid);
           ResultSet rs =st.executeQuery(query);
           rs.absolute(i);
        if(rs.previous())
            {
                 byte[] img=rs.getBytes("photo");
                 ImageIcon image=new ImageIcon(img);
                 Image im=image.getImage();
                 Image myImg=im.getScaledInstance(lblphoto2.getWidth(),lblphoto2.getWidth(),Image.SCALE_SMOOTH);
                 ImageIcon newImage =new ImageIcon(myImg);
                 lblphoto2.setIcon(newImage);
                 
             }
            else
            {
                JOptionPane.showMessageDialog(null,"REACHED THE START");
            }
           } catch (SQLException ex) {
             Logger.getLogger(Profile.class.getName()).log(Level.SEVERE, null, ex);
             JOptionPane.showMessageDialog(null,"exception"+ ex);

         }
    }//GEN-LAST:event_jLabel3MouseClicked

    private void lblaboutus1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblaboutus1MouseClicked
        // TODO add your handling code here:
        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        lblexplore.setBackground(new java.awt.Color(204, 204, 255));
        lbladdflat.setBackground(new java.awt.Color(204, 204, 255));
        lblaboutus1.setBackground(Color.WHITE);
        lblprofile.setBackground(new java.awt.Color(204, 204, 255));
        lblana.setBackground(new java.awt.Color(204, 204, 255));
        jLabel7.setBackground(new java.awt.Color(204, 204, 255));
        lblsignout.setBackground(new java.awt.Color(204, 204, 255));

        jPanel4.removeAll();
        jPanel4.repaint();
        jPanel4.revalidate();
        jPanel4.add(plabout);
        jPanel4.repaint();
        jPanel4.revalidate();

    }//GEN-LAST:event_lblaboutus1MouseClicked

    private void lblsignoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsignoutMouseClicked
        // TODO add your handling code here:

        lblaboutus1.setBackground(new java.awt.Color(204, 204, 255));
        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        lblexplore.setBackground(new java.awt.Color(204, 204, 255));
        lbladdflat.setBackground(new java.awt.Color(204, 204, 255));
        lblana.setBackground(new java.awt.Color(204, 204, 255));
        lblprofile.setBackground(new java.awt.Color(204, 204, 255));
        planalysis.setBackground(new java.awt.Color(204, 204, 255));
        jLabel7.setBackground(new java.awt.Color(204, 204, 255));
        lblsignout.setBackground(Color.WHITE);

        Home obj=new Home();
        obj.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_lblsignoutMouseClicked

    private void lblanaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblanaMouseClicked
        // TODO add your handling code here:

        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        lblexplore.setBackground(new java.awt.Color(204, 204, 255));
        lbladdflat.setBackground(new java.awt.Color(204, 204, 255));
        lblana.setBackground(Color.WHITE);
        lblprofile.setBackground(new java.awt.Color(204, 204, 255));

        jLabel7.setBackground(new java.awt.Color(204, 204, 255));
        lblsignout.setBackground(new java.awt.Color(204, 204, 255));
        lblaboutus1.setBackground(new java.awt.Color(204, 204, 255));

        jPanel4.removeAll();
        jPanel4.repaint();
        jPanel4.revalidate();
        jPanel4.add(planalysis);
        jPanel4.repaint();
        jPanel4.revalidate();

    }//GEN-LAST:event_lblanaMouseClicked

    private void lbladdflatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbladdflatMouseClicked
        // TODO add your handling code here:
        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        lblexplore.setBackground(new java.awt.Color(204, 204, 255));
        lbladdflat.setBackground(Color.WHITE);
        lblana.setBackground(new java.awt.Color(204, 204, 255));
        lblprofile.setBackground(new java.awt.Color(204, 204, 255));
        // planalysis.setBackground(new java.awt.Color(204, 204, 255));
        jLabel7.setBackground(new java.awt.Color(204, 204, 255));
        lblsignout.setBackground(new java.awt.Color(204, 204, 255));
        lblaboutus1.setBackground(new java.awt.Color(204, 204, 255));

        jPanel4.removeAll();
        jPanel4.repaint();
        jPanel4.revalidate();
        jPanel4.add(pladd);
        jPanel4.repaint();
        jPanel4.revalidate();
    }//GEN-LAST:event_lbladdflatMouseClicked

    private void lblexploreMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblexploreMouseClicked
        // TODO add your handling code here:
        j=0;
        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        lblexplore.setBackground(Color.WHITE);
        lbladdflat.setBackground(new java.awt.Color(204, 204, 255));
        lblana.setBackground(new java.awt.Color(204, 204, 255));
        lblprofile.setBackground(new java.awt.Color(204, 204, 255));
        jLabel7.setBackground(new java.awt.Color(204, 204, 255));
        planalysis.setBackground(new java.awt.Color(204, 204, 255));
        lblaboutus1.setBackground(new java.awt.Color(204, 204, 255));

        jPanel4.removeAll();
        jPanel4.repaint();
        jPanel4.revalidate();
        jPanel4.add(plexplore);
        jPanel4.repaint();
        jPanel4.revalidate();

        jLabel22.setBackground(Color.WHITE);
        jPanel22.removeAll();
        jPanel22.repaint();
        jPanel22.revalidate();
        jPanel22.add(pnldisplay1);
        jPanel22.repaint();
        jPanel22.revalidate();

        flag=false;
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");

            Statement st=con.createStatement();
            Statement st2=con.createStatement();
            rs1=st.executeQuery(queryy);
            int i=0;

            while(rs1.next() && flag==false)
            {

                if(i%3==0)
                {lbl1area.setText((rs1.getString("location")));
                    lbl1price.setText(rs1.getString("rent"));
                    lbl1type.setText(rs1.getString("stay"));
                    lbl1bhk.setText(rs1.getString("type"));
                    fid1=rs1.getInt("f_id");
                    
                    String query=("select photo from fphoto where f_id="+ fid1);
                    ResultSet rs3 =st2.executeQuery(query);
                    if(rs3.next())
                    {
                     byte[] img=rs3.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic1.getWidth(),lblpic1.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic1.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                }

                if(i%3==1)
                {lbl2area.setText((rs1.getString("location")));
                    lbl2price.setText(rs1.getString("rent"));
                    lbl2type.setText(rs1.getString("stay"));
                    lbl2bhk.setText(rs1.getString("type"));
                    fid2=rs1.getInt("f_id");
                    
                    String query=("select photo from fphoto where f_id="+ fid2);
                    ResultSet rs32 =st2.executeQuery(query);
                    if(rs32.next())
                    {
                     byte[] img=rs32.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic2.getWidth(),lblpic2.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic2.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                }

                if(i%3==2)
                {lbl3area.setText((rs1.getString("location")));
                    lbl3price.setText(rs1.getString("rent"));
                    lbl3type.setText(rs1.getString("stay"));
                    lbl3bhk.setText(rs1.getString("type"));
                    flag=true;
                    fid3=rs1.getInt("f_id");
                    
                    String query=("select photo from fphoto where f_id="+ fid3);
                    ResultSet rs31 =st2.executeQuery(query);
                    if(rs31.next())
                    {
                     byte[] img=rs31.getBytes("photo");
                     ImageIcon image=new ImageIcon(img);
                     Image im=image.getImage();
                     Image myImg=im.getScaledInstance(lblpic3.getWidth(),lblpic3.getWidth(),Image.SCALE_SMOOTH);
                     ImageIcon newImage =new ImageIcon(myImg);
                     lblpic3.setIcon(newImage);
                     }
                     else
                     {
                          JOptionPane.showMessageDialog(null,"NO PHOTO");
                     }
                }

                i++;
            }
            //  JOptionPane.showMessageDialog(null,"DATA FETCHED");

        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }

        }
        /*
        private void lbleditMouseClicked(java.awt.event.MouseEvent evt) {

            // TODO add your handling code here:

            lbldisplay.setBackground(new java.awt.Color(240, 240, 240));
            lbledit.setBackground(Color.WHITE);

            try{
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");

                Statement st=con.createStatement();
                String query=("select * from owner where o_id="+id);
                ResultSet rs =st.executeQuery(query);
                if(rs.first())
                {
                    txtfname.setText(rs.getString("fname"));
                    txtlname.setText(rs.getString("lname"));
                    txtcontact.setText(rs.getString("contact"));

                }
                // JOptionPane.showMessageDialog(null,"DATA FETCHED");

            }

            catch(SQLException e)
            {
                JOptionPane.showMessageDialog(null,"exception"+ e);
            }

    }//GEN-LAST:event_lblexploreMouseClicked
*/
    
    private void lblprofileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblprofileMouseClicked
        // TODO add your handling code here:
        lblaboutus1.setBackground(new java.awt.Color(204, 204, 255));
        jLabel1.setBackground(new java.awt.Color(204, 204, 255));
        lblexplore.setBackground(new java.awt.Color(204, 204, 255));
        lbladdflat.setBackground(new java.awt.Color(204, 204, 255));
        lblana.setBackground(new java.awt.Color(204, 204, 255));
        lblprofile.setBackground(Color.WHITE);
        jLabel7.setBackground(new java.awt.Color(204, 204, 255));
        lblsignout.setBackground(new java.awt.Color(204, 204, 255));
        // planalysis.setBackground(new java.awt.Color(204, 204, 255));
        
        lbldisplay.setOpaque(true);
        lbledit.setOpaque(true);
        lbledit.setBackground(new java.awt.Color(204, 204, 255));
        lbldisplay.setBackground(Color.WHITE);
        
        jPanel4.removeAll();
        jPanel4.repaint();
        jPanel4.revalidate();
        jPanel4.add(plprofile);
        jPanel4.repaint();
        jPanel4.revalidate();

        jPanel22.removeAll();
        jPanel22.repaint();
        jPanel22.revalidate();
        jPanel22.add(pnldisplay1);
        jPanel22.repaint();
        jPanel22.revalidate();
        
        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");

            Statement st=con.createStatement();
            String query=("select * from owner where o_id="+id);
            ResultSet rs =st.executeQuery(query);
            if(rs.first())
            {
                lblname2.setText((rs.getString("fname").concat(" ")).concat(rs.getString("lname")));
                lblcontact2.setText(rs.getString("contact"));
                lblemail2.setText(rs.getString("email"));
            }
            // JOptionPane.showMessageDialog(null,"DATA FETCHED");
            query=("select * from photo1 where o_id="+ id);
            rs =st.executeQuery(query);
            if(rs.next())
            {
                byte[] img=rs.getBytes("photo");
                ImageIcon image=new ImageIcon(img);
                Image im=image.getImage();
                Image myImg=im.getScaledInstance(lblphoto3.getWidth(),lblphoto3.getWidth(),Image.SCALE_SMOOTH);
                ImageIcon newImage =new ImageIcon(myImg);
                lblphoto3.setIcon(newImage);
            }
            else
            {
                JOptionPane.showMessageDialog(null,"NO PHOTO");
            }
        }

        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }

    }//GEN-LAST:event_lblprofileMouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:

        JFileChooser chooser =new JFileChooser();
        chooser.showOpenDialog(null);
        File f=chooser.getSelectedFile();
        filename =f.getAbsolutePath();
        JOptionPane.showMessageDialog(null,filename);
        ImageIcon imageicon =new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(lblphoto2.getWidth(),lblphoto2.getHeight(),Image.SCALE_SMOOTH));
        lblphoto2.setIcon(imageicon);
        imageicon =new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(lblphoto1.getWidth(),lblphoto1.getHeight(),Image.SCALE_SMOOTH));
        lblphoto1.setIcon(imageicon);

        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");

            Statement st=con.createStatement();
            File file =new File(filename);
            FileInputStream fis=new FileInputStream(file);

            PreparedStatement ps=con.prepareStatement("insert into photo1 values(?,?)");
            ps.setInt(1,id);
            ps.setBinaryStream(2, fis,(int)file.length());

            ps.executeUpdate();
            ps.close();

            fis.close();
            con.close();
            JOptionPane.showMessageDialog(null,"DATA UPDATED SUCCESSFULLY");

        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Exception "  +e);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:

        JFileChooser chooser =new JFileChooser();
        chooser.showOpenDialog(null);
        File f=chooser.getSelectedFile();
        filename =f.getAbsolutePath();
        JOptionPane.showMessageDialog(null,filename);
        ImageIcon imageicon =new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(lblphoto2.getWidth(),lblphoto2.getHeight(),Image.SCALE_SMOOTH));
        lblphoto2.setIcon(imageicon);
        imageicon =new ImageIcon(new ImageIcon(filename).getImage().getScaledInstance(lblphoto1.getWidth(),lblphoto1.getHeight(),Image.SCALE_SMOOTH));
        lblphoto1.setIcon(imageicon);

        try{
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");

            Statement st=con.createStatement();
            File file =new File(filename);
            FileInputStream fis=new FileInputStream(file);

            PreparedStatement ps=con.prepareStatement("UPDATE photo1 set photo=? where o_id=?");
            ps.setInt(2,id);
            ps.setBinaryStream(1, fis,(int)file.length());

            ps.executeUpdate();
            ps.close();

            fis.close();
            con.close();
            JOptionPane.showMessageDialog(null,"DATA UPDATED SUCCESSFULLY");

        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"Exception "  +e);
        }

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:

        try
        {
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/flat_search","root","root");
            Statement st=con.createStatement();

            String query=("update owner set fname='"+ txtfname.getText() +"',lname='"  +  txtlname.getText()   + "',contact='" + txtcontact.getText()+ "' where o_id=" + id);
            st.executeUpdate(query);

            JOptionPane.showMessageDialog(null,"DATA UPDATED SUCCESSFULLY");
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,"exception"+ e);
        }

    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtlnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtlnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtlnameActionPerformed

    private void txtcontactActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtcontactActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtcontactActionPerformed

    private void lblphoto1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblphoto1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_lblphoto1MouseClicked

    private void lblphoto3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblphoto3MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_lblphoto3MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Profile(2).setVisible(true);
            }
        });
    
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addflat1;
    private javax.swing.JButton btnpiearea;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JCheckBox chkac;
    private javax.swing.JCheckBox chkbalcony;
    private javax.swing.JCheckBox chkfilter;
    private javax.swing.JCheckBox chkfurnished;
    private javax.swing.JCheckBox chkgeyser;
    private javax.swing.JCheckBox chkinverter;
    private javax.swing.JCheckBox chklift;
    private javax.swing.JCheckBox chksecurity;
    private javax.swing.JCheckBox chkwash;
    private javax.swing.JComboBox cmbtype;
    private javax.swing.JComboBox comboloc;
    private javax.swing.JComboBox date;
    private javax.swing.JLabel flatimg;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JCheckBox jCheckBox11;
    private javax.swing.JFormattedTextField jFormattedTextField1;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel33;
    private javax.swing.JPanel jPanel34;
    private javax.swing.JPanel jPanel35;
    private javax.swing.JPanel jPanel36;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JLabel laddress;
    private javax.swing.JLabel laddress1;
    private javax.swing.JLabel laddress2;
    private javax.swing.JLabel laddress3;
    private javax.swing.JLabel laddress4;
    private javax.swing.JLabel laddress5;
    private javax.swing.JLabel laddress6;
    private javax.swing.JLabel laddress7;
    private javax.swing.JLabel lbl1area;
    private javax.swing.JLabel lbl1bhk;
    private javax.swing.JLabel lbl1price;
    private javax.swing.JLabel lbl1size;
    private javax.swing.JLabel lbl1type;
    private javax.swing.JLabel lbl2area;
    private javax.swing.JLabel lbl2bhk;
    private javax.swing.JLabel lbl2price;
    private javax.swing.JLabel lbl2size;
    private javax.swing.JLabel lbl2type;
    private javax.swing.JLabel lbl3area;
    private javax.swing.JLabel lbl3bhk;
    private javax.swing.JLabel lbl3price;
    private javax.swing.JLabel lbl3size;
    private javax.swing.JLabel lbl3type;
    private javax.swing.JLabel lblaboutus1;
    private javax.swing.JLabel lbladdflat;
    private javax.swing.JLabel lblam;
    private javax.swing.JLabel lblana;
    private javax.swing.JLabel lblcontact1;
    private javax.swing.JLabel lblcontact2;
    private javax.swing.JLabel lblcount;
    private javax.swing.JLabel lblcount2;
    private javax.swing.JLabel lbldisplay;
    private javax.swing.JLabel lbledit;
    private javax.swing.JLabel lblemail1;
    private javax.swing.JLabel lblemail2;
    private javax.swing.JLabel lblexplore;
    private javax.swing.JLabel lblname1;
    private javax.swing.JLabel lblname2;
    private javax.swing.JLabel lblphoto1;
    private javax.swing.JLabel lblphoto2;
    private javax.swing.JLabel lblphoto3;
    private javax.swing.JLabel lblpic1;
    private javax.swing.JLabel lblpic2;
    private javax.swing.JLabel lblpic3;
    private javax.swing.JLabel lblprofile;
    private javax.swing.JLabel lblresult;
    private javax.swing.JLabel lblsignout;
    private javax.swing.JLabel ldate;
    private javax.swing.JLabel ldate1;
    private javax.swing.JLabel ldescription1;
    private javax.swing.JLabel lfloor;
    private javax.swing.JLabel lfloor1;
    private javax.swing.JLabel llocation;
    private javax.swing.JLabel llocation2;
    private javax.swing.JLabel lrent;
    private javax.swing.JLabel lrent1;
    private javax.swing.JLabel lstay;
    private javax.swing.JLabel ltype;
    private javax.swing.JLabel ltype1;
    private javax.swing.JLabel ltype2;
    private javax.swing.JComboBox month;
    private javax.swing.JPanel plabout;
    private javax.swing.JPanel pladd;
    private javax.swing.JPanel planalysis;
    private javax.swing.JPanel plexplore;
    private javax.swing.JPanel plprofile;
    private javax.swing.JPanel plprofile1;
    private javax.swing.JPanel pnldisplay1;
    private javax.swing.JPanel pnledit;
    private javax.swing.JPanel pnlflat;
    private javax.swing.JRadioButton rbtnany;
    private javax.swing.JRadioButton rbtnboys;
    private javax.swing.JRadioButton rbtngirls;
    private javax.swing.JRadioButton rbtnoff;
    private javax.swing.JTextField txtcontact;
    private javax.swing.JTextArea txtdescription;
    private javax.swing.JTextField txtfloor;
    private javax.swing.JTextField txtfname;
    private javax.swing.JTextField txtlname;
    private javax.swing.JTextField txtlocation;
    private javax.swing.JTextField txtlocation1;
    private javax.swing.JTextField txtrent;
    private javax.swing.JButton upload;
    private javax.swing.JComboBox year;
    // End of variables declaration//GEN-END:variables
}
